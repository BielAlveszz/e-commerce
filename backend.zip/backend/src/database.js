const { Pool } = require('pg');

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: parseInt(process.env.DB_PORT) || 5432,
});

// Exporta query para consultas simples e connect para transações (BEGIN/COMMIT/ROLLBACK)
module.exports = {
  query: (text, params) => pool.query(text, params),
  connect: () => pool.connect(),
};