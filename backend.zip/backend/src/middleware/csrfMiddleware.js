const logger = require('../utils/logger');

const csrfMiddleware = (req, res, next) => {
    // Apenas validamos métodos que alteram o estado do servidor (ignora GET, OPTIONS, etc.)
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
        const origin = req.headers.origin;
        const referer = req.headers.referer;
        const allowedOrigin = process.env.FRONTEND_URL || 'http://localhost:3000';

        // O browser envia sempre o Origin ou Referer em requests cross-origin que usam POST/PUT/DELETE
        const requestSource = origin || referer;

        if (!requestSource || !requestSource.startsWith(allowedOrigin)) {
            logger.warn(`Tentativa de CSRF bloqueada. Origem detetada: ${requestSource || 'Desconhecida'} | IP: ${req.ip}`);
            return res.status(403).json({ 
                message: 'Acesso negado. Falha na validação de origem da requisição (Segurança Anti-CSRF).' 
            });
        }
    }
    next();
};

module.exports = csrfMiddleware;