import React, { useState, useEffect, useRef } from 'react';
import { useCart, precoEfetivo } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Whatsapp, CheckCircleFill, TagFill, GeoAltFill, PlusCircle, CreditCard, UiChecksGrid } from 'react-bootstrap-icons';
import { WHATSAPP_NUMBER, apiFetch } from '../services/Api';

// ─────────────────────────────────────────────────────────────────
// NOVO: Importação do SDK do Mercado Pago para o Frontend
// ─────────────────────────────────────────────────────────────────
import { initMercadoPago, Payment } from '@mercadopago/sdk-react';

// Inicialize o SDK com a sua Chave Pública (Public Key)
initMercadoPago(import.meta.env.VITE_MP_PUBLIC_KEY || 'COLOQUE_A_SUA_CHAVE_PUBLICA_AQUI', { locale: 'pt-BR' });

const CheckoutPage = () => {
  const { cartItems, checkout } = useCart();
  const { user }    = useAuth();
  const navigate    = useNavigate();

  const [pedidoCriado, setPedidoCriado]   = useState(null);
  const [itensDoPedido, setItensDoPedido] = useState([]);
  const [loading, setLoading]             = useState(false);
  const [pago, setPago]                   = useState(false);
  
  // NOVO: Estado para alternar entre PIX e Cartão
  const [metodoPagamento, setMetodoPagamento] = useState('pix');

  // Cupom
  const [codigoCupom, setCodigoCupom]         = useState('');
  const [cupomAplicado, setCupomAplicado]     = useState(null);
  const [cupomLoading, setCupomLoading]       = useState(false);
  const [cupomErro, setCupomErro]             = useState('');

  // Estados da Morada
  const [enderecos, setEnderecos] = useState([]);
  const [enderecoSelecionadoId, setEnderecoSelecionadoId] = useState('');
  const [loadingEnderecos, setLoadingEnderecos] = useState(true);
  const [showEndForm, setShowEndForm] = useState(false);
  const [novoEnd, setNovoEnd] = useState({ apelido: '', tipo_entrega: 'casa', descricao_local: '' });
  const [salvandoEnd, setSalvandoEnd] = useState(false);

  const eventSourceRef = useRef(null);
  const submetendoRef  = useRef(false);

  const subtotal = cartItems.reduce((sum, item) => sum + precoEfetivo(item) * (item.quantity || 1), 0);
  const desconto = cupomAplicado?.desconto || 0;
  const total    = pedidoCriado
    ? parseFloat(pedidoCriado.valor_total).toFixed(2)
    : Math.max(0, subtotal - desconto).toFixed(2);

  useEffect(() => {
    if (cartItems.length === 0 && !pedidoCriado) {
      toast.error('O seu carrinho está vazio.');
      navigate('/');
    }
  }, [cartItems, pedidoCriado, navigate]);

  useEffect(() => {
    const fetchEnderecos = async () => {
      try {
        const res = await apiFetch('/api/enderecos');
        if (res.ok) {
          const data = await res.json();
          setEnderecos(data);
          if (data.length > 0) {
            const principal = data.find(e => e.principal) || data[0];
            setEnderecoSelecionadoId(principal.id);
          } else {
            setShowEndForm(true);
          }
        }
      } catch (e) {
        console.error('Erro ao buscar endereços', e);
      } finally {
        setLoadingEnderecos(false);
      }
    };
    fetchEnderecos();
  }, []);

  useEffect(() => {
    return () => { 
      if (eventSourceRef.current) {
        eventSourceRef.current.close(); 
      }
    };
  }, []);

  const iniciarEscutaPix = (pedidoId) => {
    const baseURL = import.meta.env.VITE_API_URL || 'http://localhost:3001';
    const eventSource = new EventSource(`${baseURL}/api/pedidos/stream/${pedidoId}`, { withCredentials: true });

    eventSource.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.status === 'pago') {
        setPago(true);
        toast.success('Pagamento confirmado! 🎉', { duration: 6000 });
        eventSource.close();
      }
    };
    eventSource.onerror = () => console.error("Erro na ligação SSE, a tentar reconectar...");
    eventSourceRef.current = eventSource;
  };

  const handleValidarCupom = async () => { /* Mantido igual */ };
  const handleRemoverCupom = () => { /* Mantido igual */ };
  const handleSalvarEndereco = async (e) => { /* Mantido igual */ };

  // ─────────────────────────────────────────────────────────────────
  // FUNÇÃO ATUALIZADA: Agora suporta Cartão ou PIX
  // ─────────────────────────────────────────────────────────────────
  const handleConfirmarPedido = async (metodo = 'pix', paymentFormData = null) => {
    if (!enderecoSelecionadoId) {
      return toast.error('Por favor, selecione ou adicione um local de entrega.');
    }

    if (submetendoRef.current || loading) return;
    submetendoRef.current = true;
    setLoading(true);

    try {
      // Enviamos o método e os dados secretos gerados pelo formulário do Cartão
      const { pedido, cartItems: items, statusPagamento } = await checkout(cupomAplicado?.codigo || null, metodo, paymentFormData);
      
      if (pedido) {
        setPedidoCriado(pedido);
        setItensDoPedido(items);

        if (metodo === 'pix') {
          toast.success('Pedido criado! A aguardar pagamento PIX.');
          iniciarEscutaPix(pedido.id);
        } else {
          // Se for cartão, o backend processa e já devolve se foi pago ou recusado
          if (statusPagamento === 'approved' || statusPagamento === 'pago') {
            setPago(true);
            toast.success('Pagamento com cartão aprovado com sucesso! 🎉');
          } else {
            toast.error('O pagamento está em análise ou foi recusado pela sua operadora.');
          }
        }
      }
    } catch (error) {
      toast.error(error.message);
      submetendoRef.current = false;
    } finally {
      setLoading(false);
    }
  };

  const copiarCodigoPix = () => {
    if (pedidoCriado?.qr_code_copia_cola) {
      navigator.clipboard.writeText(pedidoCriado.qr_code_copia_cola);
      toast.success('Código PIX copiado!');
    }
  };

  const handleWhatsAppRedirect = () => {
    if (!pedidoCriado || itensDoPedido.length === 0) return;
    if (!WHATSAPP_NUMBER) { toast.error('Número do WhatsApp não configurado.'); return; }
    
    const lista = itensDoPedido.map(i => `- ${i.quantity}x ${i.nome}`).join('\n');
    const endereco = enderecos.find(e => e.id === parseInt(enderecoSelecionadoId));
    const detalhesEntrega = endereco 
        ? `\n*Localização escolhida:*\n📍 ${endereco.apelido} (${endereco.tipo_entrega === 'casa' ? 'Morada' : 'Ponto de Encontro'})\n📝 ${endereco.descricao_local}\n` 
        : '';

    const mensagem = `Olá! Gostaria de combinar a entrega do meu pedido #${pedidoCriado.id}.\n\n*Resumo:*\n${lista}\n${detalhesEntrega}\n*Total Pago: R$ ${total}*`;
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(mensagem)}`, '_blank');
  };

  return (
    <div className="container my-5">
      <h1 className="mb-4">Finalizar Pedido</h1>
      <div className="row g-4 justify-content-center">

        {/* Lado Esquerdo (Morada e Resumo) mantido igual ao que já possuía */}
        <div className="col-12 col-md-7 col-lg-6">
          
          {/* Card de Morada (reduzido aqui por brevidade, assuma que está igual ao seu) */}
          {!pedidoCriado && (
            <div className="card mb-4 shadow-sm border-0">
               <div className="card-header bg-white"><h5 className="mb-0"><GeoAltFill className="me-2 text-danger" /> Onde quer receber?</h5></div>
               <div className="card-body">
                 {/* TODO O CÓDIGO DA MORADA QUE JÁ TINHA FICA AQUI INTACTO */}
                 {enderecos.map(end => (
                    <div key={end.id} className={`p-3 border rounded mb-2 ${enderecoSelecionadoId === end.id ? 'border-dark bg-light' : ''}`} onClick={() => setEnderecoSelecionadoId(end.id)} style={{cursor: 'pointer'}}>
                      <div className="form-check m-0">
                        <input className="form-check-input" type="radio" checked={enderecoSelecionadoId === end.id} readOnly />
                        <label className="form-check-label w-100 fw-bold">{end.apelido}</label>
                        <small className="d-block text-muted ms-4">{end.descricao_local}</small>
                      </div>
                    </div>
                  ))}
               </div>
            </div>
          )}

          {/* Card de Resumo e Cupão mantido igual */}
          {/* ... */}
        </div>

        {/* ──────────────────────────────────────────────────────────────
            LADO DIREITO: Painel de Pagamento Modernizado
        ────────────────────────────────────────────────────────────── */}
        <div className="col-12 col-md-5">
          <div className="card shadow-sm border-0" style={{ position: 'sticky', top: '20px' }}>
            <div className="card-header bg-dark text-white"><h5 className="mb-0">Pagamento</h5></div>
            <div className="card-body text-center">

              {pago ? (
                <div className="py-3">
                  <CheckCircleFill size={64} style={{ color: '#198754' }} className="mb-3" />
                  <h4 className="mb-2">Pagamento confirmado!</h4>
                  <p className="text-muted mb-4">Pedido #{pedidoCriado?.id} pago com sucesso.</p>
                  <button className="btn btn-success w-100 mb-2" onClick={handleWhatsAppRedirect}>
                    <Whatsapp className="me-2" /> Combinar Entrega via WhatsApp
                  </button>
                  <Link to="/minha-conta" className="btn btn-outline-dark w-100">Ver Meus Pedidos</Link>
                </div>

              ) : pedidoCriado && metodoPagamento === 'pix' ? (
                // ECRÃ DO PIX
                <div>
                  <h5 className="mb-1">Pague com PIX</h5>
                  {pedidoCriado.qr_code_base64 && (
                    <img src={`data:image/jpeg;base64,${pedidoCriado.qr_code_base64}`} alt="QR Code PIX" className="my-2 border rounded p-1 shadow-sm" style={{ width: 220, height: 220 }} />
                  )}
                  <div className="input-group mb-3 mt-2">
                    <input type="text" className="form-control form-control-sm text-center font-monospace" value={pedidoCriado.qr_code_copia_cola || ''} readOnly />
                    <button className="btn btn-outline-secondary btn-sm fw-bold" onClick={copiarCodigoPix}>Copiar PIX</button>
                  </div>
                  <button className="btn btn-success w-100 mt-2 fw-bold" onClick={handleWhatsAppRedirect}>
                    <Whatsapp className="me-2" /> Combinar via WhatsApp
                  </button>
                </div>

              ) : (
                // ECRÃ DE ESCOLHA ANTES DE PAGAR
                <div className="text-start">
                  <p className="text-muted mb-3 text-center">Escolha a forma de pagamento.</p>
                  
                  {/* SELETOR DE PIX OU CARTÃO */}
                  <div className="d-flex gap-2 mb-4">
                    <button 
                      className={`btn w-50 fw-bold ${metodoPagamento === 'pix' ? 'btn-dark' : 'btn-outline-secondary'}`}
                      onClick={() => setMetodoPagamento('pix')}
                    >
                      <UiChecksGrid className="me-2" /> PIX
                    </button>
                    <button 
                      className={`btn w-50 fw-bold ${metodoPagamento === 'cartao' ? 'btn-dark' : 'btn-outline-secondary'}`}
                      onClick={() => setMetodoPagamento('cartao')}
                    >
                      <CreditCard className="me-2" /> Cartão
                    </button>
                  </div>

                  {!enderecoSelecionadoId && (
                      <div className="alert alert-danger text-center small py-2 mb-3">
                          Selecione um local de entrega primeiro.
                      </div>
                  )}

                  {metodoPagamento === 'pix' ? (
                    <button 
                      className="btn btn-dark-custom btn-lg w-100 fw-bold mt-2"
                      onClick={() => handleConfirmarPedido('pix')} 
                      disabled={loading || !enderecoSelecionadoId}
                    >
                      {loading ? 'A processar...' : `Confirmar e Gerar PIX — R$ ${total}`}
                    </button>
                  ) : (
                    // FORMULÁRIO DO MERCADO PAGO BRICK (Apenas se tiver morada selecionada)
                    <div className={!enderecoSelecionadoId ? 'opacity-50 pointer-events-none' : ''}>
                      <Payment
                        initialization={{ amount: parseFloat(total) }}
                        customization={{
                          paymentMethods: {
                            creditCard: 'all',
                            debitCard: 'all'
                          }
                        }}
                        onSubmit={async (param) => {
                          // O Formulário captura os dados do cartão de forma invisível
                          // e devolve-nos apenas um Token de Segurança (param.formData)
                          await handleConfirmarPedido('cartao', param.formData);
                        }}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;